/**
  * SupprimerPlusGrand supprime les valeurs plus grandes qu'un seuil.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class SupprimerPlusGrand extends Traitement {
	private double seuil;
	
	/**
	 * Constructeur du traitement SupprimerPlusGrand*
	 * @param seuil à supprimer le ou les valeurs plus grand que le seuil
	 * */
	public SupprimerPlusGrand(double seuil) {
		this.seuil = seuil;
	}

	@Override
	protected String toStringComplement() {
		
 		return "seuil = "+seuil;
	}

	@Override
	public void traiter(Position position, double valeur) {
		if(valeur <= seuil) {
			super.traiter(position, valeur);
		}		
	}

}
