import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
  * Donnees enregistre toutes les donnÃ©es reÃ§ues, quelque soit le lot.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class Donnees extends Traitement {

private Map<Position, Double> donneesList = new HashMap<>();
/**
 * Constructeur du traitement Donnees.
 * @param donneList l'enregistrement des données traités.
 */
public Donnees() {
	super();
	this.donneesList = new HashMap<>();
}

public Map<Position, Double>  getDonneeList() {
	return donneesList;
}


public void setDonneeList(Map<Position, Double>  donneeList) {
	this.donneesList = donneeList;
}


@Override
protected String toStringComplement() {
	
	return "Liste des données traités:"+donneesList;
}

@Override
public void traiter(Position position, double valeur) {
	donneesList.put( position, valeur);
	super.traiter(position, valeur);
}

@Override
protected void gererDebutLotLocal(String nomLot) {
	super.gererDebutLotLocal(nomLot);
	donneesList.clear();
}

@Override
protected void gererFinLotLocal(String nomLot) {
	super.gererFinLotLocal(nomLot);
	System.out.println("Données traités dnas le lot : "+ nomLot+"sont:"+ donneesList);
}
public void enregisterDansFichier(String nomFichier) throws IOException{
	try(BufferedWriter ecrire = new BufferedWriter(new FileWriter(nomFichier) )){
		int identifiant = 1;
		for(Map.Entry<Position, Double> entry: donneesList.entrySet()) {
			ecrire.write(identifiant +" "+entry.getKey().getX()+" "+entry.getKey().getY()+" " + entry.getValue());
			ecrire.newLine();
			identifiant ++;
			
		}
		System.out.println(new File(nomFichier).getAbsolutePath());
	}
}
}
