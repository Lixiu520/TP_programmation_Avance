
# Format des fichiers

* Type1 : x, y, id, valeur
* Type2 : id, x, y, texte, valeur, texte[0]


# Fichiers

## Fichier .txt

* Fichier -f2.txt : Type2
* donnees-erreur.txt : Type2
* Autres fichiers .txt : Type1

