public class CycleException {
}
