/**
  * Multiplicateur transmet la valeur multipliÃ©e par un facteur.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class Multiplicateur extends Traitement {
	private double facteur;	
	/**
     * Constructeur du traitement Multiplicateur.
     * @param facteur le facteur par lequel les valeurs seront multipliées.
     */
	public Multiplicateur(double facteur) {
		super();
		this.facteur = facteur;
	}

	@Override
	protected String toStringComplement() {		
		return "facteur est :"+facteur;
	}

	@Override
	public void traiter(Position position, double valeur) {
		double nouvelleValeur = valeur * facteur;
		super.traiter(position, nouvelleValeur);
	}
}
