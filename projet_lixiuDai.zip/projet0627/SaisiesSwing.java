import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.*;
import javax.swing.border.*;

public class SaisiesSwing   {
	public SaisiesSwing(Donnees dns, String nomFichier) {
		JFrame fenetre = new JFrame("Saisie données");
		fenetre.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Container  font= fenetre.getContentPane();
		font.setLayout(new BorderLayout());
		JPanel contenu = new JPanel(new BorderLayout());
		contenu.setBorder(new EmptyBorder(5,5,5,5));
		font.add(contenu);
		//la partie saisie
		JPanel saisies = new JPanel();
		saisies.setLayout(new GridLayout(3,1));
		
		JPanel abscisse = new JPanel(new GridLayout(1,2));
		JPanel ordonnee = new JPanel(new GridLayout(1,2));
		JPanel vleur = new JPanel(new GridLayout(1,2));
		
		JPanel labelABS = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		JLabel abscLabel = new JLabel("Abscisse : ");
		labelABS.add(abscLabel );
		JTextField abscText = new JTextField();
		abscText.setBackground(Color.white);
		
		abscisse.add(labelABS );
		abscisse.add(abscText);
		
		
		JPanel labelORD = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		JLabel ordnLabel = new JLabel("Ordonnee : ");
		labelORD.add(ordnLabel );
		JTextField ordnText = new JTextField();
		ordnText.setBackground(Color.white);
		ordonnee.add(labelORD );
		ordonnee.add(ordnText);

		JPanel labelVlr = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JLabel vlrLabel = new JLabel("Valeur : ");
		JTextField vlrText = new JTextField();
		vlrText.setBackground(Color.white);
		labelVlr.add(vlrLabel );
		vleur.add(labelVlr );
		vleur.add(vlrText);
		
		
		saisies.add(abscisse, FlowLayout.LEFT);
		saisies.add(ordonnee, FlowLayout.CENTER);
		saisies.add(vleur, FlowLayout.RIGHT);
		
		//la partie boutons
		JPanel boutons = new JPanel(new GridLayout(1,3, 10,10));
		JButton valider = new JButton("Valider");
		JButton effacer = new JButton("Effacer");
		JButton terminer = new JButton("Terminer");
		
		boutons.add(valider);
		boutons.add(effacer);
		boutons.add(terminer);
		
		valider.addActionListener(av->{
			try {
			int abs = Integer.parseInt(abscText.getText());
			int ordn = Integer.parseInt(ordnText.getText());
			
			Position ps = new Position(abs, ordn);
			double valeur = Double.parseDouble(vlrText.getText());
			dns.traiter(ps, valeur);
			}
			catch(NumberFormatException e) {
				if(!vlrText.getText().matches("\\d+")) {
					vlrText.setBackground(Color.red);

				}
				if(!abscText.getText().matches("\\d+")) {
					abscText.setBackground(Color.red);

				}
				if(!ordnText.getText().matches("\\d*\\.?\\d+")) {
					ordnText.setBackground(Color.red);
				}
			}
		});
		
		effacer.addActionListener(av->{
			vlrText.setText("");
			vlrText.setBackground(Color.white);
			abscText.setText("");
			abscText.setBackground(Color.white);
			ordnText.setText("");
			ordnText.setBackground(Color.white);
		});
		
		terminer.addActionListener(av->{
			try {
				dns.enregisterDansFichier(nomFichier);
			} catch (IOException e) {				
				e.printStackTrace();
			}
			System.exit(1);
		});	

		contenu.add(saisies, BorderLayout.NORTH);
		contenu.add(boutons,BorderLayout.SOUTH);
		fenetre.setSize(400,150);
		fenetre.setVisible(true);
		
		fenetre.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
	}
	  public static void main(String[] args) {
	        Donnees donnees = new Donnees();
	        new SaisiesSwing(donnees, "testSwing.txt");
	    }
}
