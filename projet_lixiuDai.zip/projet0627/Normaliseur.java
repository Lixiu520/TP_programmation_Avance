import java.util.ArrayList;
import java.util.List;

/**
  * Normaliseur normalise les donnÃ©es d'un lot en utilisant une transformation affine.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class Normaliseur extends Traitement {

 private double debut;
 private double fin;
 private double minValeur = Double.POSITIVE_INFINITY;
 private double maxValeur = Double.NEGATIVE_INFINITY;
 private List<Double> donneeList = new ArrayList<>();
 /**
  * Constructeur du traitement Normalisateur.
  * @param debut début de l'intervalle de normalisation.
  * @param fin fin de l'intervalle de normalisation.
  */
 public Normaliseur(double debut, double fin) {
     this.debut = debut;
     this.fin = fin;
 }
@Override
protected String toStringComplement() {
	return "Debut = "+debut+", fin = "+fin;
}
@Override
public void traiter(Position position, double valeur) {
	
	if (valeur < minValeur) {
		minValeur = valeur;
	}
	if(valeur > maxValeur) {
		maxValeur = valeur;
	}
	donneeList.add(valeur);
	super.traiter(position, valeur);
}
@Override
protected void gererDebutLotLocal(String nomLot) {
	super.gererDebutLotLocal(nomLot);
	donneeList.clear();
	minValeur =  Double.POSITIVE_INFINITY;
	maxValeur = Double.NEGATIVE_INFINITY;
}
/**
 * Normaliser les valeurs données dans l'intervalle [debut, fin].
 */
protected List<Double> normaliser() {
	List<Double> valeurNormalisees = new ArrayList<>();
	double a = (fin-debut)/(maxValeur-minValeur);
	double b = fin - a*maxValeur;
	for(double donnee : donneeList) {
		double  valeurNormalisee = a*donnee+b;
		valeurNormalisees.add(valeurNormalisee);
	}
	return valeurNormalisees;
}

@Override
protected void gererFinLotLocal(String nomLot) {
    // Normaliser les valeurs
    List<Double> valeursNormalisees = normaliser();

    // Transmettre les valeurs normalisées aux traitements suivants
    for (int i = 0; i < donneeList.size(); i++) {
        super.traiter(new Position(i, 0), valeursNormalisees.get(i));
    }
}
 
 
}