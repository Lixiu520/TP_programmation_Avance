
public class Donnee {
 private final Position position;
 private final double valeur;
public Donnee(Position position, double valeur) {
	super();
	this.position = position;
	this.valeur = valeur;
}
@Override
public String toString() {
	return "position : " + position + ", Valeur : "+valeur ;
}
 
 
}
