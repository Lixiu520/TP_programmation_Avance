/**
  * Somme calcule la sommee des valeurs, quelque soit le lot.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */

public class Somme extends SommeAbstrait {
	/** Obtenir le somme .
	 * @return somme le somme
	 */
	@Override
	public double somme() {
		return somme;
	}

	
	

}
