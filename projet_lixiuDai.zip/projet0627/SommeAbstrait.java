/**
  * SommeAbstrait 
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */

abstract public class SommeAbstrait extends Traitement {
	protected double somme = 0;
	
	public abstract double somme();

	@Override
	protected String toStringComplement() {
		String resultat = super.toStringComplement();
		resultat += "sommeActuel = "+somme;
		return resultat;
	}

	@Override
	public void traiter(Position position, double valeur) {
		somme += valeur;
		super.traiter(position, valeur);
	}

	@Override
	protected void gererDebutLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererDebutLotLocal(nomLot);
		somme = 0;
	}

	@Override
	protected void gererFinLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererFinLotLocal(nomLot);
		System.out.println(nomLot + ": somme = " + somme);
	}
	
	

}
