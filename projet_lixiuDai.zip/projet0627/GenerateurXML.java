import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;

/**
 * GenerateurXML Ã©crit dans un fichier, Ã  charque fin de lot, toutes
 * les donnÃ©es lues en indiquant le lot dans le fichier XML.
 *
 * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
 */
public class GenerateurXML extends Traitement {
	private String nomFichier;
	private Document document;
	private Element racine;
	private List<Element> elementDonnees = new ArrayList<>();
	
	
	/**
     * Constructeur du traitement GenerateurXML.
     * @param nomFichier le nom de fichier pour enregistrer.
     */
	public GenerateurXML(String nomFichier) {
		this.nomFichier = nomFichier;
		this.elementDonnees = new ArrayList<>();
	}


	@Override
	protected String toStringComplement() {
		
		return "nom du fichier est : " + nomFichier;
	}


	@Override
	public void traiter(Position position, double valeur) {
		Element elementDonnee = document.createElement("donnee");
		elementDonnee.setAttribute("id", String.valueOf(position.hashCode()));
		elementDonnee.setAttribute("x", String.valueOf(position.getX()));
		
		
		Element elementValeur = document.createElement("valeur");
		elementValeur.appendChild(document.createTextNode(String.valueOf(valeur)));

		Element elementY=document.createElement("y");
		elementY.appendChild(document.createTextNode(String.valueOf(position.getY())));
		
		elementDonnee.appendChild(elementValeur);
		elementDonnee.appendChild(elementY);
		
		elementDonnees.add(elementDonnee);

		super.traiter(position, valeur);
	
	}


	@Override
	protected void gererDebutLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererDebutLotLocal(nomLot);
	}


	@Override
	protected void gererFinLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererFinLotLocal(nomLot);
	}
	

}
