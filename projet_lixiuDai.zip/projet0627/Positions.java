import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
  * Positions enregistre toutes les positions, quelque soit le lot.
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class Positions extends PositionsAbstrait {
	//list des positions dans l'ordre de traitement 
	private List<Position> positionList = new ArrayList<>();
	// associer la posiiton et nombre de traitement ce ce position
	private Map<Position, Integer> positionFrequence = new HashMap<>();
	
	
	public Positions() {
		super();
	}

	public Positions(List<Position> positionList) {
		super();
		this.positionList = positionList;
	}

	@Override
	public int nombre() {		
		return this.positionList.size();
	}

	@Override
	public Position position(int indice) {
		if(indice<0 || indice >= positionList.size()) {
			throw new IndexOutOfBoundsException("Indice incorrecte: " + indice);
		}
		return positionList.get(indice);
	}

	@Override
	public int frequence(Position position) {
		return positionFrequence.getOrDefault(position, 0);
	}

	@Override
	protected String toStringComplement() {
		String resultat = super.toStringComplement();
		resultat += "nombre positions  = " + nombre();
		return resultat;
	}

	@Override
	public void traiter(Position position, double valeur) {
		positionList.add(position);
		positionFrequence.put(position, positionFrequence.getOrDefault(position,0)+1);
		super.traiter(position, valeur);
	}

	@Override
	protected void gererDebutLotLocal(String nomLot) {
		super.gererDebutLotLocal(nomLot);
		positionList.clear();
		positionFrequence.clear();
		
	}

	@Override
	protected void gererFinLotLocal(String nomLot) {
		super.gererFinLotLocal(nomLot);
		System.out.println("Positions traitées dans le lot " +nomLot +":"  + positionList);
	}

	
}
