import java.util.*;

/**
  * SommeParPosition 
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */

public class SommeParPosition extends Traitement {
	private Map<Position, Double> sommeParPosition = new HashMap<>();

	@Override
	protected String toStringComplement() {
		String resultat = super.toStringComplement();
		resultat +=  "Somme par position = " +sommeParPosition.size() +" positions";
		return resultat; 
	}

	@Override
	public void traiter(Position position, double valeur) {		
		sommeParPosition.put(position,  sommeParPosition.getOrDefault(position, 0.0)+valeur);
		super.traiter(position, valeur);
	}

	@Override
	protected void gererDebutLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererDebutLotLocal(nomLot);
		sommeParPosition.clear();
	}

	@Override
	protected void gererFinLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererFinLotLocal(nomLot);
		System.out.println("SommeParPosition" +nomLot +" :");
		for (Map.Entry<Position,Double> entry : sommeParPosition.entrySet( )) {
			System.out.println(" - " + entry.getKey()+" ->" +entry.getValue());
		}
		System.out.println("Fin somme par position .");
	}

	

}
