import java.lang.reflect.*;
import java.util.*;

/**
  * TraitementBuilder 
  *
  * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
  */
public class TraitementBuilder {
	private FabriqueTraitement fabrique;
	
	

	public TraitementBuilder() {
		this.fabrique = new FabriqueTraitementConcrete();
	}

	/** Retourne un objet de type Class correspondant au nom en paramÃ¨tre.
	 * Exemples :
	 *   - int donne int.class
	 *   - Normaliseur donne Normaliseur.class
	 */
	Class<?> analyserType(String nomType) throws ClassNotFoundException {
		switch(nomType) {
		case "int": 
			return int.class;
		case "double": 
			return double.class;
		case "String":
			return String.class;
		case "Traitement": 
			return Traitement.class;
		case "Position": 
			return Position.class;
		case "Normaliseur": 
			return Normaliseur.class;
		case "Analyseur": 
			return Analyseur.class;
		case "Donnees": 
			return Donnees.class;
		case "GenerateurXML": 
			return GenerateurXML.class;
		case "Max": 
			return Max.class;
		case "Maj": 
			return Maj.class;
		case "FabriqueTraitement": 
			return FabriqueTraitement.class;
		case "Multiplicateur": 
			return Multiplicateur.class;
		case "Positions": 
			return Positions.class;
		case "SupprimerPlusGrand": 
			return SupprimerPlusGrand.class;
		case "SupprimerPlusPetit": 
			return SupprimerPlusPetit.class;
			
		case "Somme": 
			return Somme.class;
		default: 
			try {
			return Class.forName(nomType);
			}catch(ClassNotFoundException e) {
				throw new RuntimeException("Type incconu "+ nomType, e);
			}
			
		}
		  
	}

	/** CrÃ©e l'objet java qui correspond au type formel en exploitant le Â« mot Â» suivant du scanner.
	 * Exemple : si formel est int.class, le mot suivant doit Ãªtre un entier et le rÃ©sulat est l'entier correspondant.
	 * Ici, on peut se limiter aux types utlisÃ©s dans le projet : int, double et String.
	 */
	static Object decoderEffectif(Class<?> formel, Scanner in) {
		if(formel == int.class) {
			return in.nextInt();
		}else if (formel == double.class) {
			return in.nextDouble();
		}else if (formel == String.class) {
			return in.next();
		}
		throw new IllegalArgumentException("Unsupported type:" + formel);
		
		//return null;	// TODO Ã  remplacer
	}
	


	/** DÃ©finition de la signature, les paramÃ¨tres formels, mais aussi les paramÃ¨tres formels.  */
	static class Signature {
		Class<?>[] formels;
		Object[] effectifs;

		public Signature(Class<?>[] formels, Object[] effectifs) {
			this.formels = formels;
			this.effectifs = effectifs;
		}
	}

	/** Analyser une signature pour retrouver les paramÃ¨tres formels et les paramÃ¨tres effectifs.
	 * Exemple Â« 3 double 0.0 java.lang.String xyz int -5 Â» donne
	 *   - [double.class, String.class, int.class] pour les paramÃ¨tres effectifs et
	 *   - [0.0, "xyz", -5] pour les paramÃ¨tres formels.
	 */
	Signature analyserSignature(Scanner in) throws ClassNotFoundException {
		int nbParam = in.nextInt();
		
		Class<?>[] formels = new Class<?>[nbParam];
		Object[] effectifs = new Object[nbParam];
		
		for (int i =0; i< nbParam; i++) {
			String typeParam = in.next();
			formels[i] = analyserType(typeParam);
			effectifs[i]=decoderEffectif(formels[i], in);
		}
		return new Signature(formels, effectifs);	// TODO Ã  remplacer
	}


	/** Analyser la crÃ©ation d'un objet.
	 * Exemple : Â« Normaliseur 2 double 0.0 double 100.0 Â» consiste Ã  charger
	 * la classe Normaliseur, trouver le constructeur qui prend 2 double, et
	 * l'appeler en lui fournissant 0.0 et 100.0 comme paramÃ¨tres effectifs.
	 */
	Object analyserCreation(Scanner in)
		throws ClassNotFoundException, InvocationTargetException,
						  IllegalAccessException, NoSuchMethodException,
						  InstantiationException
	{
		String nomClasse = in.next();
		Class<?> classe = analyserType(nomClasse);
		Signature signature = analyserSignature(in);
		Constructor<?> constructeur = classe.getConstructor(signature.formels);
		return constructeur.newInstance(signature.effectifs);	// TODO Ã  remplacer
	}


	/** Analyser un traitement.
	 * Exemples :
	 *   - Â« Somme 0 0 Â»
	 *   - Â« SupprimerPlusGrand 1 double 99.99 0 Â»
	 *   - Â« Somme 0 1 Max 0 0 Â»
	 *   - Â« Somme 0 2 Max 0 0 SupprimerPlusGrand 1 double 20.0 0 Â»
	 *   - Â« Somme 0 2 Max 0 0 SupprimerPlusGrand 1 double 20.0 1 Positions 0 0 Â»
	 * @param in le scanner Ã  utiliser
	 * @param env l'environnement oÃ¹ enregistrer les nouveaux traitements
	 */
	Traitement analyserTraitement(Scanner in, Map<String, Traitement> env)
		throws ClassNotFoundException, InvocationTargetException,
						  IllegalAccessException, NoSuchMethodException,
						  InstantiationException
	{
		String nomTraitement = in.next();
		int nbSuivants = in.nextInt();
		Traitement traitement =(Traitement) analyserCreation(in);
		for(int i= 0; i< nbSuivants; i++) {
			Traitement suivant = analyserTraitement(in, env);
			traitement.ajouterSuivants(suivant);
		}
		return traitement;	
	}


	/** Analyser un traitement.
	 * @param in le scanner Ã  utiliser
	 * @param env l'environnement oÃ¹ enregistrer les nouveaux traitements
	 */
	public Traitement traitement(Scanner in, Map<String, Traitement> env)
	{
		try {
			return analyserTraitement(in, env);
		} catch (Exception e) {
			throw new RuntimeException("Erreur sur l'analyse du traitement, "
					+ "voir la cause ci-dessous", e);
		}
	}

}
