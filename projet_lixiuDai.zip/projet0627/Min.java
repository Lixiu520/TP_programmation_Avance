import java.util.List;

public class Min extends Traitement {
	
	private double minValeur = Double.POSITIVE_INFINITY;

	public Min() {
		super();
		this.minValeur = Double.POSITIVE_INFINITY;
	}

	public double getMinValeur() {
		return minValeur;
	}

	public void setMinValeur(double minValeur) {
		this.minValeur = minValeur;
	}
	

	@Override
	protected String toStringComplement() {
		
		return "le minimum des valeurs est: "+ minValeur;
	}

	@Override
	public void traiter(Position position, double valeur) {
		if(valeur < minValeur) {
			minValeur= valeur;
		}
		super.traiter(position, valeur);
	}

	@Override
	protected void gererDebutLotLocal(String nomLot) {		
		super.gererDebutLotLocal(nomLot);
		minValeur = Double.POSITIVE_INFINITY;
	}

	@Override
	protected void gererFinLotLocal(String nomLot) {
		// TODO Auto-generated method stub
		super.gererFinLotLocal(nomLot);
		System.out.println("dans les données : "+nomLot +", le minimum des valeurs est : " +minValeur);
	}
	
	

}
