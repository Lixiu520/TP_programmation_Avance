/**
 * Max calcule le max des valeurs vues, quelque soit le lot.
 *
 * @author Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
 */

public class Max extends Traitement {

	private double maxValeur = Double.NEGATIVE_INFINITY;

	public Max() {
		super();
		this.maxValeur = Double.NEGATIVE_INFINITY;
	}

	public double getMaxValeur() {
		return maxValeur;
	}

	public void setMaxValeur(double maxValeur) {
		this.maxValeur = maxValeur;
	}

	@Override
	public void traiter(Position position, double valeur) {
		if (valeur > maxValeur) {
			maxValeur = valeur;
		}
		super.traiter(position, valeur);
	}

	@Override
	protected String toStringComplement() {

		return "le maximume des valeurs est : " + maxValeur;
	}

	@Override
	protected void gererDebutLotLocal(String nomLot) {
		super.gererDebutLotLocal(nomLot);
		maxValeur = Double.NEGATIVE_INFINITY;
	}

	@Override
	protected void gererFinLotLocal(String nomLot) {
		super.gererFinLotLocal(nomLot);
		System.out.println("dans les données : " + nomLot + ", le maximume des valeurs est : " + maxValeur);
	}

}
