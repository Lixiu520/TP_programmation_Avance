import java.util.HashMap;
import java.util.Map;

/**
 * Maj indique pour chaque lot les positions mises Ã  jour (ou ajoutÃ©es)
 * lors du traitement de ce lot.
 *
 * @author	Xavier CrÃ©gut <Prenom.Nom@enseeiht.fr>
 */
public class Maj extends Traitement {
	
	    private Map<Position, Double> positionValeurMap;
	    private Map<Position, Double> positionsMisAJour;

	    public Maj() {
	        this.positionValeurMap = new HashMap<>();
	        this.positionsMisAJour = new HashMap<>();
	    }

	    @Override
	    public void traiter(Position position, double valeur) {
	        if (positionValeurMap.containsKey(position)) {
	            // Mettre à jour la valeur si elle a changé
	            if (positionValeurMap.get(position) != valeur) {
	                positionsMisAJour.put(position, valeur);
	                positionValeurMap.put(position, valeur);
	            }
	        } else {
	            // Nouvelle position ajoutée
	            positionsMisAJour.put(position, valeur);
	            positionValeurMap.put(position, valeur);
	        }

	        // Transmettre aux traitements suivants
	        super.traiter(position, valeur);
	    }

	    @Override
	    protected void gererDebutLotLocal(String nomLot) {
	        // Réinitialiser les positions mises à jour pour le nouveau lot
	        positionsMisAJour.clear();
	    }

	    @Override
	    protected void gererFinLotLocal(String nomLot) {
	        // Afficher les positions mises à jour ou ajoutées pour le lot courant
	        System.out.println(nomLot + ": positions mises à jour ou ajoutées = " + positionsMisAJour.keySet());

	        // Transmettre la fin du lot aux traitements suivants
	        super.gererFinLot(nomLot);
	    }
	}
