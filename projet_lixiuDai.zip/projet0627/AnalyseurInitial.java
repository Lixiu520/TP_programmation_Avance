import java.io.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

/** Analyser des donnÃ©es d'un fichier, une donnÃ©e par ligne avec 4 informations
 * sÃ©parÃ©es par des blancs : x, y, ordre (ignorÃ©e), valeur.
 */
public class AnalyseurInitial {
	private Donnees dns;
	
	
	public AnalyseurInitial( ) {
		super();
		this.dns = new Donnees();
	}



	public Donnees getDns() {
		return dns;
	}



	public void setDns(Donnees dns) {
		this.dns = dns;
	}



	/** Charger l'analyseur avec les donnÃ©es du fichier "donnees.java". */
	public void traiter(String nomFichier) {
		try (BufferedReader in = new BufferedReader(new FileReader(nomFichier))) {
			if (nomFichier.endsWith("txt")) {
				double somme = 0.0;
				String ligne = null;
				while ((ligne = in.readLine()) != null) {
					String[] mots = ligne.split("\\s+");
					if (mots.length == 4) {	// 4 mots sur chaque ligne
					double valeur = Double.parseDouble(mots[3]);
					System.out.println(valeur);
					int x = Integer.parseInt(mots[0]);
					int y = Integer.parseInt(mots[1]);
					Position p = new Position(x, y);
					somme += valeur;
					System.out.println("Fichier type1:somme = "+somme);
					dns.traiter(p, valeur);						
					
					}else if (mots.length ==6) {
						double valeur = Double.parseDouble(mots[4]);
						System.out.println(valeur);
						somme += valeur;
						int x = Integer.parseInt(mots[1]);
						int y = Integer.parseInt(mots[2]);
						Position p = new Position(x,y);	
						dns.traiter(p, valeur);
						System.out.println("Fichier type2:somme = "+somme);
					}
					
				}
			} else if (nomFichier.endsWith("xml")) {
				File fichier = new File(nomFichier);
				DocumentBuilderFactory dbF = DocumentBuilderFactory.newInstance();
				DocumentBuilder dbB = dbF.newDocumentBuilder();
				Document doc = dbB.parse(fichier); 
				doc.getDocumentElement().normalize();
				NodeList nlist= doc.getElementsByTagName("donnee");
				for(int i=0; i<nlist.getLength(); i++) {
					Node nNode = nlist.item(i);
					if(nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element e = (Element)nNode;
						int x = Integer.parseInt(e.getAttribute("x"));
						int y = Integer.parseInt(e.getElementsByTagName("y").item(0).getTextContent());
						double valeur = Double.parseDouble(e.getElementsByTagName("valeur").item(0).getTextContent());
						Position p = new Position(x,y);
						dns.traiter(p, valeur);						
					}
				}						
			}
		}catch (ParserConfigurationException | SAXException | IOException e) {
				throw new RuntimeException(e);
			}								
		}
	

 
	public static void main(String[] args) {
		new AnalyseurInitial().traiter ("donnees.txt");
		new AnalyseurInitial().traiter ("donnees2-f2.txt");
		//new AnalyseurInitial().traiter ("donnees6.dtd");
	}

}
